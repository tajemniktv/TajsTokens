(* TajsTokens mathematical research, 27 October 2026.
   These two expressions were evaluated with the connected Wolfram tool.
   They are synthetic/algebraic checks, not a fit to user telemetry.
   ClearAll separates the originally stateless evaluations for local reruns.
   Run each association expression to inspect its output. *)

ClearAll["Global`*"];
Clear[a,b,p,tau,t1,t2,x1,x2,w1,w2,b1,b2];
bounds=FullSimplify[
 (b1*x1+b2*x2)/(w1*x1+w2*x2)==
 (w1*x1/(w1*x1+w2*x2))*(b1/w1)+
 (w2*x2/(w1*x1+w2*x2))*(b2/w2),
 Assumptions->{x1>=0,x2>=0,x1+x2>0,w1>0,w2>0}];
constraints={a>=0,b>=0,9<=a+b<=11};
marginalExample=<|
 "MarginalFeaturesForBoth"->{1,1,1,1},
 "ModelCategoryWeights"->{1,5,10,50},
 "WorkloadA"->{1,0,0,1},"WorkloadB"->{0,1,1,0},
 "Costs"->({1,5,10,50}.#&/@{{1,0,0,1},{0,1,1,0}})|>;
<|
 "ScalarConversionWeightedAverageIdentity"->bounds,
 "SameMixPredictionBounds"->{
  MinValue[{a+b,constraints},{a,b}],
  MaxValue[{a+b,constraints},{a,b}]},
 "UnseenPureCategoryBounds"->{
  MinValue[{2*a,constraints},{a,b}],
  MaxValue[{2*a,constraints},{a,b}]},
 "AddSecondMix2aPlusbBetween14And16_PureCategoryBounds"->{
  MinValue[{2*a,Join[constraints,{14<=2*a+b<=16}]},{a,b}],
  MaxValue[{2*a,Join[constraints,{14<=2*a+b<=16}]},{a,b}]},
 "LostJointFeatureCounterexample"->marginalExample,
 "ElapsedTimeDecaySemigroup"->FullSimplify[
  Exp[-t1/tau]*Exp[-t2/tau]==Exp[-(t1+t2)/tau],
  Assumptions->{tau>0,t1>=0,t2>=0}],
 "Legacy17FlatPolls"->N[13.971596243*(3/4)^17,12]
|>

(* Results: True; {9,11}; {0,22}; {6,14}; costs {51,15};
   True; 0.10502374592418827. *)

ClearAll["Global`*"];
Clear[r,n,c,u,t0,t1,a,b];
h=2008006569/1000000000;
constraints={75/2<=t0<=77/2,89/2<=t1<=91/2};
<|
 "UnknownReasoningSplitEqualWeights"->{
  MinValue[{5*r+5*n,r>=0&&n>=0&&r+n==1000},{r,n}],
  MaxValue[{5*r+5*n,r>=0&&n>=0&&r+n==1000},{r,n}]},
 "UnknownCacheSplitDifferentWeights"->{
  MinValue[{u+c/10,u>=0&&c>=0&&u+c==1000},{u,c}],
  MaxValue[{u+c/10,u>=0&&c>=0&&u+c==1000},{u,c}]},
 "HistoricalBracketPointRatePpPerHour"->N[7/h,12],
 "RoundingOnlyRateBounds"->N[{6/h,8/h},12],
 "HistoricalConstantRateRunwayHours"->N[55*h/7,12],
 "CoupledRoundingOnlyRunwayBoundsHours"->N[{
  h*(100-91/2)/(91/2-75/2),
  h*(100-89/2)/(89/2-77/2)},12],
 "AdjacentDifferenceNoiseCovariance"->Expand[(a-b)*(b-c)],
 "UniversalScalarConversionCondition"->Reduce[
  ForAll[{u,c},Implies[u>=0&&c>=0,
   b1*u+b2*c==k*(w1*u+w2*c)]],{b1,b2},Reals]
|>

(* Results: {5000,5000}; {100,1000}; 3.48604437259687;
   {2.98803803365446,3.98405071153928}; 15.7771944707143;
   {13.6795447513125,18.57406076325};
   a*b-b^2-a*c+b*c; b1==k*w1 && b2==k*w2. *)
