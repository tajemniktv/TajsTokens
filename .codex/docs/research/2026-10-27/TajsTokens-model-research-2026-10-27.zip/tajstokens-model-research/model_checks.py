"""Reproducible mathematical checks for the 2026-10-27 TajsTokens research.

These are synthetic demonstrations and arithmetic checks, not a fitted user model,
a replay of the user's database, or tests of the C# application.
Requires Python 3.10+, NumPy and SciPy. Run: python model_checks.py
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Sequence

import numpy as np
from scipy.optimize import linprog


def linear_range(
    objective: Sequence[float],
    *,
    inequalities: Sequence[Sequence[float]] | None = None,
    limits: Sequence[float] | None = None,
    equalities: Sequence[Sequence[float]] | None = None,
    totals: Sequence[float] | None = None,
) -> tuple[float, float]:
    """Min/max a linear quantity over nonnegative feasible variables."""
    c = np.asarray(objective, dtype=float)
    values: list[float] = []
    for sign in (1.0, -1.0):
        result = linprog(
            sign * c,
            A_ub=inequalities,
            b_ub=limits,
            A_eq=equalities,
            b_eq=totals,
            bounds=[(0.0, None)] * len(c),
            method="highs",
        )
        if not result.success:
            raise RuntimeError(f"Linear optimization failed: {result.message}")
        values.append(float(sign * result.fun))
    return values[0], values[1]


def check_equal(actual: Any, expected: Any) -> None:
    if not np.allclose(actual, expected, rtol=1e-10, atol=1e-10):
        raise AssertionError(f"Expected {expected!r}, got {actual!r}")


def main() -> dict[str, Any]:
    results: dict[str, Any] = {}

    # Joint coordinates: A-input, A-output, B-input, B-output.
    weights = np.array([1.0, 5.0, 10.0, 50.0])
    a = np.array([1.0, 0.0, 0.0, 1.0])
    b = np.array([0.0, 1.0, 1.0, 0.0])
    # Marginal coordinates: all-input, all-output, all-A, all-B.
    marginalizer = np.array([[1, 0, 1, 0], [0, 1, 0, 1],
                            [1, 1, 0, 0], [0, 0, 1, 1]])
    check_equal(marginalizer @ a, marginalizer @ b)
    check_equal([weights @ a, weights @ b], [51, 15])
    assert np.linalg.matrix_rank(marginalizer) == 3
    results["joint_feature_counterexample"] = {
        "same_marginals": (marginalizer @ a).tolist(),
        "cost_A": float(weights @ a), "cost_B": float(weights @ b),
        "ratio": float((weights @ a) / (weights @ b)),
        "marginalizer_rank": 3,
        "qualification": "All weights are invented abstract units, not provider rates.",
    }

    # Repeated 1:1 mixes identify a+b, not a and b separately.
    A = [[1, 1], [-1, -1]]
    u = [11, -9]
    same = linear_range([1, 1], inequalities=A, limits=u)
    unseen = linear_range([2, 0], inequalities=A, limits=u)
    varied = linear_range([2, 0], inequalities=A + [[2, 1], [-2, -1]],
                          limits=u + [16, -14])
    check_equal(same, (9, 11))
    check_equal(unseen, (0, 22))
    check_equal(varied, (6, 14))
    results["partial_identification"] = {
        "same_mix": same, "unseen_pure_mix": unseen,
        "pure_mix_after_one_different_mix": varied,
        "qualification": "Feasibility ranges under deterministic assumptions, not confidence intervals.",
    }

    exact = linear_range([5, 5], equalities=[[1, 1]], totals=[1000])
    bounded = linear_range([1, 0.1], equalities=[[1, 1]], totals=[1000])
    check_equal(exact, (5000, 5000))
    check_equal(bounded, (100, 1000))
    results["missing_subdivision"] = {"equal_weights": exact,
                                        "different_weights": bounded}

    # Given independent level errors of variance 1/12, adjacent differences
    # share an endpoint and have covariance -1/12 (a toy assumption only).
    D = np.array([[-1.0, 1.0, 0.0], [0.0, -1.0, 1.0]])
    covariance = D @ (np.eye(3) / 12.0) @ D.T
    check_equal(covariance, [[1/6, -1/12], [-1/12, 1/6]])
    results["toy_adjacent_difference_covariance"] = covariance.tolist()

    # Numbers in the supplied memo, not a new database replay.
    h = 2.008006569
    point_rate = 7.0 / h
    point_runway = 55.0 / point_rate
    rate_bounds = (6.0 / h, 8.0 / h)
    # Joint endpoint uncertainty: start 38, end 45, nearest-integer rounding.
    # Both the remaining amount and the fitted rate depend on the final endpoint.
    runway_bounds = (h * 54.5 / 8, h * 55.5 / 6)
    decay = 13.971596243 * 0.75**17
    check_equal(decay, 0.10502374592418827)
    results["memo_arithmetic"] = {
        "legacy_rate_after_17_flat_polls": decay,
        "bracket_rate_pp_per_hour": point_rate,
        "rounding_only_rate_range": rate_bounds,
        "constant_bracket_rate_runway_hours": point_runway,
        "coupled_rounding_only_runway_hours": runway_bounds,
        "qualification": "Assumes fresh nearest-integer endpoints, constant historical average, no resets/lag. Not a forecast interval.",
    }

    # Clock-time decay composes by elapsed time; fixed-per-poll decay does not.
    check_equal(math.exp(-0.7/2) * math.exp(-0.9/2), math.exp(-1.6/2))
    results["elapsed_decay_semigroup"] = True

    # Scalar conversion is a convex combination of category-specific ratios.
    w = np.array([1.0, 0.1, 5.0])
    beta = np.array([0.03, 0.006, 0.1])
    x = np.array([100.0, 500.0, 20.0])
    tt = w @ x
    p = w * x / tt
    ratio = (beta @ x) / tt
    check_equal(ratio, p @ (beta / w))
    assert min(beta/w) <= ratio <= max(beta/w)
    results["mixture_conversion"] = {"quota_per_tt": float(ratio),
                                      "supported_category_range": [float(min(beta/w)), float(max(beta/w))]}

    # Overlap with a measurement interval does not prove coverage of its latent truth.
    observed = (9.0, 11.0)
    predicted = (9.9, 10.1)
    truth = 9.2
    intersects = predicted[1] >= observed[0] and predicted[0] <= observed[1]
    contains_whole_observation = predicted[0] <= observed[0] and predicted[1] >= observed[1]
    covers_truth = predicted[0] <= truth <= predicted[1]
    assert intersects and not contains_whole_observation and not covers_truth
    results["interval_overlap_counterexample"] = {
        "measurement_interval": observed, "prediction_interval": predicted,
        "possible_latent_truth": truth, "intersects": intersects,
        "covers_this_possible_truth": covers_truth,
    }
    results["status"] = "All mathematical and synthetic checks passed. No production model validated."
    return results


if __name__ == "__main__":
    output = main()
    serialized = json.dumps(output, indent=2, allow_nan=False)
    destination = Path(__file__).with_name("check_results.json")
    destination.write_text(serialized + "\n", encoding="utf-8")
    print(serialized)
