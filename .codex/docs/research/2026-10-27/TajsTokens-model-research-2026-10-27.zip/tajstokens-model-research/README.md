# TajsTokens model research package

27 October 2026. Read-only research against repository commit
`e609aebee78712dd26c2eae040005e6dcf2377f3` and the supplied accounting/forecasting memo.

Start with `RESEARCH.md`. It contains the recommendations, scoped source findings,
mathematical derivations, qualifications and primary-source bibliography.

## Reproduce the mathematical checks

`model_checks.py` requires Python 3.10 or later, NumPy and SciPy. In a suitable
Python environment, run:

```sh
python model_checks.py
```

It checks the examples and writes `check_results.json` next to the script.
The included JSON was produced by a successful run during this research.

`wolfram_checks.wl` retains the two expressions evaluated with the connected
Wolfram tool. Evaluate each association expression in Wolfram Language to inspect
its output. The clear operations separate the originally stateless evaluations.

These computations use invented examples plus explicitly identified arithmetic
from the supplied memo. They are not application tests, a database replay, a fit
to personal usage, or evidence of production forecast accuracy. No model traffic
was generated and no repository or installed application was changed.
