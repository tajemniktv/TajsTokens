# TajsTokens models: research addendum

**27 October 2026 · Research and design proposals, not an implementation mandate**

## Decision

Keep the supplied memo's architecture. Strengthen it with a measurement-aware, support-aware modelling contract:

> Preserve the joint workload information; establish which quantities are identifiable; return exact values, defensible bounds, conditional forecasts, or an explicit unavailable result according to the evidence.

This is not a proposal to replace the application, introduce a neural predictor, install a statistical service, or expand background collection. The existing accounting, forecasting, SQLite and immutable-basis owners are the appropriate starting points. The original memo and `PROJECT.md` retain their existing roles. These notes are supporting research, not another competing roadmap.

The principal additions are:

1. Preserve **model × token-category** combinations. The current richer quota feature vector loses that pairing.
2. Treat **identification ranges**, **meter precision**, and **predictive uncertainty** as different quantities.
3. Make answer requirements depend on the requested calculation. Missing subdivisions sometimes permit an exact score, not just a partial one.
4. Model quota readings as observations of an accumulated process, not as independent exact per-poll consumption.
5. Forecast the distribution of **crossing an allowance threshold**, including the possibility of no crossing before reset.
6. Keep TT as a frozen reference-consumption convention. Do not infer a universal latent resource from billing-derived indicators.

## 1. Evidence, scope and limitations

The supplied source was **TajsTokens-accounting-forecasting-TT-research-2026-10-27.md**, including its October 27 architecture, PACE-001 and performance updates. Its distinction between agreed direction and undecided implementation details is preserved here.

A read-only GitHub check confirmed `main` at **e609aebee78712dd26c2eae040005e6dcf2377f3**, the same revision discussed in that memo. Targeted source inspection covered:

- `QuotaAccountingModel.cs`, including feature construction, interval ridge fitting, first-20 training and evaluation-band semantics.
- `QuotaCostObservationBuilder.cs`, including interval construction, chronology, rounded targets and saturated-outcome exclusion.
- `QuotaPaceModels.cs`, including fixed-per-poll and elapsed-time-weighted estimators.
- `CodexForecastFeatureBuilder.cs`, including model/effort marginal shares and collection-time availability.
- `TtWorkloadBasis.cs`, including its five pooled category weights and support requirements.
- `TT_LAYERED_STATISTICAL_DESIGN.md` and the consolidated audit register.

Primary external sources were consulted for rounded measurements, bounded-error identification, composite-index construction, forecasting evaluation, scenario interpretation, censoring and conformal prediction. Current official OpenAI documentation was checked for pricing-versus-allowance semantics. Sources are listed at the end.

**What was run:** two Wolfram evaluations containing symbolic checks and synthetic constrained optimizations; independent Python/NumPy/SciPy checks of the mathematical examples. `model_checks.py` and `check_results.json` are included.

**What was not run:** the C# test suite, the application, a local telemetry database replay, a fit to the user's actual usage history, paid inference, benchmark prompts, remote-device operations, or a production-model change. No accuracy, learned coefficient, personal quota capacity or numerical production threshold is established by this work. The supplied memo's incident numbers were used for arithmetic, not independently recovered from logs.

The literature review is targeted, not an exhaustive systematic review. For the bounded-error identification and intermittent-demand papers, publicly available abstracts support the limited methodological descriptions below; their complete implementations were not reproduced. The conformal paper's introduction/figure and the relevant OECD weighting/sensitivity pages were inspected in rendered PDF form.

## 2. What changes from the earlier proposal

### 2.1 A universal latent TT is not the default destination

The earlier idea of learning one latent quantity from quota, prices, credits and resource signals was too ambitious as a default. Prices and credits may be transformations of the same tariff, not independent measurements of a common physical resource. A factor fitted to them can reproduce those conventions without acquiring provider-independent meaning.

The OECD/JRC treatment of composite indicators supports specifying the construct, weighting choices and sensitivity checks explicitly. A statistical weighting procedure does not eliminate the need to define what the index means. [S1]

For TajsTokens, a **frozen reference-tariff consumption index** is a practical first convention. It measures reference-weighted consumption, not intelligence, useful completed work, FLOPs, current money or an account's remaining quota. A later latent model would need an additional, explicitly justified measurement claim.

### 2.2 Nonnegative regression already exists

The source already has an interval-distance, nonnegative ridge cost model, several comparators, chronological held-out trials, and conservative evaluation labels. Proposing that family as though it were missing would be redundant. Its useful next changes concern representation, support and interpretation. [R1]

### 2.3 Better mathematics does not repair absent evidence

The memo's source-coverage and ingestion work remains upstream of empirical calibration. More sophisticated estimators cannot establish which account paid for an unassigned response, reconstruct inaccessible cloud work with certainty, or turn a late import into a timely historical observation.

However, evidence insufficiency is question-specific. A dataset can support workload scoring or a usual-mix forecast while not supporting a model-specific price decomposition. This is the central distinction to make operational.

### 2.4 Experimental design should begin passively

Instead of automatically spending quota on synthetic experiments, measure which contrasts ordinary work already supplies: different cache mixes, output mixes, models, tiers and compatible account periods. Report missing contrasts. A deliberate paid experiment is a separate, explicitly authorized decision.

## 3. Current provider facts that materially constrain the model

The current official rate card distinguishes purchased-usage pricing from included allowance consumption. It lists Fast mode at **2×** the Standard credit rate but **2.5×** the included allowance rate; supported Ultrafast examples use **6×** versus **8×**. These are documented policy distinctions, not inferred user-specific coefficients. [S2]

Official documentation also describes shared allowances across Codex and other eligible agentic surfaces. Consequently, unexplained account-wide movement need not originate in another local Codex thread or even another Codex device. [S2, S3]

OpenAI says an active turn may continue after an included limit is reached, subject to fair-use limits. Therefore an allowance threshold and the exact time execution stops are different targets. [S3]

These observations reinforce the memo rather than overturn it:

- Separate source-reported quantities, counterfactual reference valuation and learned quota conversion.
- Key applicable policy by product, account/plan, billing route, model, service tier and effective time where supported.
- Do not turn current documentation into a claim about historical October 6 pricing or the exact behavior of this user's account.
- Do not assume an API-key tariff applies to a ChatGPT-authenticated session.

The reviewed documentation also differentiates cache-write charges and route-specific context treatment. This is a reason to preserve those dimensions and policy provenance, not to introduce every conceivable feature into a small regression. [S2, S4]

## 4. New source finding: marginal features lose the joint workload

`QuotaAccountingModel.CostVector` takes pooled token-category totals and, in its richer candidate, appends token mass by model and effort. `CodexForecastFeatureBuilder` supplies those model and effort shares. The feature vector does **not** preserve the model/category cross-tabulation. [R1, R4]

That distinction is structural. Consider two synthetic models with invented per-unit weights:

| Model | Input weight | Output weight |
|---|---:|---:|
| A | 1 | 5 |
| B | 10 | 50 |

Two workloads each contain one input unit, one output unit, one unit from A and one unit from B:

- Workload 1: A supplies the input; B supplies the output. Cost = 1 + 50 = **51**.
- Workload 2: B supplies the input; A supplies the output. Cost = 10 + 5 = **15**.

Their marginal features are identical, but their true costs under this illustrative schedule differ by a factor of 3.4. No nonlinear model can recover a pairing that its input representation discarded. These numbers are not OpenAI rates. Wolfram and the independent Python check reproduce the example.

### Recommended representation

Preserve a sparse additive vector `x[model, category]`, with supported tier/product distinctions where necessary. Construct it from reconciled token events, not by multiplying separately aggregated shares. Existing events already supply a starting point for this work. Unknown model mass should remain explicitly unassigned.

Fit a small ladder:

1. Raw-total baseline.
2. Pooled-category baseline.
3. Model-specific category coefficients with shrinkage toward the pooled-category model.
4. Tier or effort departures only when supported by additional compatible evidence.

The third step need not mean a new Bayesian runtime. A constrained ridge objective can penalize departures from pooled weights while keeping final model/category coefficients nonnegative. Effort should not receive an automatic extra charge when its effect is already represented by observed token consumption.

### A related identification issue

When categories are complete and conserved, their sum equals total tokens. The model totals, including unknown-model mass, also sum to total tokens; effort totals do likewise. Those feature groups therefore contain exact linear dependencies. The richer implementation can construct as many as 39 base features before extensions while the research fit uses 20 training intervals, although the actual active feature count in the user's data was not measured. [R1]

Regularization can select a stable numerical solution. It does not prove that the selected individual coefficients are independently determined by the observations. This is the ordinary collinearity distinction between a useful prediction and an identified explanation. [S5]

## 5. A better quota observation model

### 5.1 Start with cumulative levels

For one compatible account/window/regime, let `U(t)` be latent accumulated allowance consumption in percentage points. A reading `y_j` describes `U(s_j)` at its effective provider measurement time `s_j`, which need not equal the collection time.

If nearest-integer rounding is actually justified, a non-boundary observation has the constraint:

`y_j - 0.5 <= U(s_j) < y_j + 0.5`.

Other rounding rules, clipping, cached values and reporting delay require different treatment. An integer JSON field alone does not establish the complete backend precision or timing contract. The repository already acknowledges this limitation. [R2, S6]

The statistical principle is to model the observation mechanism rather than declare the displayed value exact. A probabilistic rounded-data model assigns probability to the entire observation interval. A deterministic bounded-error model retains the interval as a constraint. These are different interpretations and should not share an unlabeled “confidence” badge. [S6, S7]

### 5.2 Adjacent deltas share errors

Writing `y_j = U_j + e_j` gives:

`Delta y_j = Delta U_j + e_j - e_(j-1)`.

Even in the simplifying toy case of independent endpoint errors with variance `sigma²`, adjacent delta errors have covariance `-sigma²`. Real rounding errors need not be independent or uniformly distributed; the example merely demonstrates why independent-delta likelihoods require justification.

Likewise, many overlapping intervals do not create many independent outcomes. Preserve endpoint identity and either work with cumulative-level constraints, use well-separated evaluation blocks, or explicitly model dependence.

### 5.3 What to ship first, and what to test next

The immediate correction remains the memo's elapsed-time-aware fallback with explicit precision and freshness. Existing recent-bracket and elapsed-time-weighted implementations should remain the first competitors. [R3]

A useful next research challenger is a **bounded local slope**: over a declared recent segment, find nonnegative slopes `r` and intercepts `a` satisfying all justified level intervals:

`lower_j <= a + r * (s_j - s_0) <= upper_j`.

This is a small linear feasibility/optimization problem. Its output is a range of slopes compatible with a constant-rate approximation, not a probability distribution for future activity. If the set is empty, do not silently erase the conflict: the chosen constant-rate approximation, timing, measurement bounds or regime assumptions failed. A robust slack version can be tested, but its tolerance needs an explicit policy.

Later, a piecewise-rate/state-space candidate can allow rates or reporting lag to vary. That complexity is justified only if it beats the simpler candidates on timely held-out evidence.

**Polling nuance:** duplicates of the same cached observation add no new measurement. A genuinely fresh unchanged reading at a later time can constrain the slope. “Every unchanged poll is redundant” is therefore also wrong. Clock-time smoothing removes a particular per-poll decay defect; it does not solve all quantization and lag problems.

### 5.4 Recalculation of the memo's example

The memo's seven displayed points over 2.008006569 hours give **3.486044373 pp/hour**. At 55 points remaining, holding that historical average constant gives **15.77719447 hours**.

Assuming fresh nearest-integer endpoint readings of 38 and 45, with no reporting lag or reset, the rounding-compatible average rate is approximately **2.988–3.984 pp/hour**. Accounting jointly for the uncertain final level and uncertain rate gives a constant-rate runway range of **13.680–18.574 hours**.

These are **rounding-only arithmetic bounds under an unchanged historical-average assumption**, not an 80% or 90% predictive interval, not a current active-work rate, and not a live exhaustion forecast. Future workload variation could dominate this uncertainty.

## 6. Partial identification: learn what the data actually constrain

For well-matched work/usage intervals, a bounded-error linear model can define:

`Theta = { beta >= 0 : lower_i <= x_i' beta <= upper_i for every retained constraint i }`.

For a particular proposed workload `x*`, solve:

`lower_prediction = min(beta in Theta) x*' beta`

`upper_prediction = max(beta in Theta) x*' beta`.

This is a set-membership identification approach. The literature provides linear-programming treatments for bounded-error regression; the proposed application here is to TajsTokens' explicitly qualified quota intervals. [S7]

This formulation is not a claim that rounding is the only source of error. Bounds for reporting lag, normalization uncertainty or model mismatch require evidence or sensitivity assumptions. If a coefficient is unobserved and unbounded, say so rather than adding an invisible prior to make a tidy number.

### Synthetic example

Suppose all informative workloads have a 1:1 input/output mix and reveal only `9 <= a+b <= 11`, with nonnegative category weights.

| Requested prediction | Feasible cost range |
|---|---:|
| Another 1:1 workload | 9–11 |
| Two input units, no output | 0–22 |
| The same pure-input workload after additionally observing `14 <= 2a+b <= 16` | 6–14 |

Wolfram and SciPy produce these bounds independently. More copies of the first mix cannot separate the category weights. A different mix contributes a genuinely new contrast.

The product consequence is important: **a conversion can be supported for the current mixture without supporting arbitrary scenario edits or a universal tariff explanation.** Availability is a property of the requested answer, not just a property of the fitted model.

### External activity is not a free latent explanation

If account movement contains unobserved external work `z_i >= 0`, constraints become:

`lower_i <= x_i' beta + z_i <= upper_i`.

With no useful restrictions on `z_i`, the data may provide upper bounds on local coefficients but no positive lower bounds. Setting local cost to zero and attributing all movement to `z_i` can satisfy the observations. A latent-state model does not remove this ambiguity.

Use provider/thread reports where scope and semantics match, bounded attribution assumptions where defensible, and sensitivity results elsewhere. An account-wide direct quota forecast can remain available even when local causal attribution is unavailable. Reporting lag or corrections must be resolved separately before interpreting interval residuals as external usage.

## 7. Missing information can still produce exact answers

Let the supported observed aggregates be `A x = b`, with nonnegative unknown detailed quantities `x`. For a frozen TT basis with weights `w`, consider the range of `w' x` over that feasible set.

Three outcomes are possible:

- The minimum and maximum coincide: the requested score is determined even though some details are missing.
- Both are finite but different: a defensible score range is available under the specified constraints.
- A useful finite bound cannot be established: expose the covered subtotal and missing dimensions, or withhold the total.

A simple sufficient condition for an exact score is `w = A' v` for some vector `v`; then `w' x = v' b`.

### Examples, with invented score weights

If total output is 1,000 and both reasoning and non-reasoning output have weight 5, the score is exactly **5,000** regardless of the unknown subdivision.

If total input is 1,000 but the cache split is unknown, with uncached weight 1 and cached weight 0.1, the score is bounded by **100–1,000**. It is not legitimate to substitute either endpoint, or a midpoint, as an observed score.

An unknown model with no supported mapping does not acquire a plausible weight just because other models have one. A truly unknown model may prevent a finite upper TT bound for the missing portion.

### Implication for existing code

`TtWorkloadBasis` currently stores five pooled category weights and checks complete categories plus supported model/effort shares. Model and effort lists act as support gates, not model-specific numerical coefficients. [R5]

A model-specific tariff TT cannot be implemented by merely adding model names to those lists. Reuse its immutability, reference normalization and hashing pattern, but introduce explicit joint model/category semantics under a new basis contract. Preserve the old research basis and scores.

For the new basis, derive requirements from the score being requested. Unknown effort need not block a tariff score whose coefficients are identical across effort. Unknown reasoning split need not block a pooled-output score. This is a targeted extension of the memo's question-specific eligibility rule, not permission to ignore provenance.

There is no requirement to run a generic optimization solver on every UI refresh. Common aggregation and equal-weight cases can have small, tested deterministic implementations; the optimization formulation supplies the research specification.

## 8. TT's recommended role and its mathematical limits

Use a frozen, dated reference schedule and a named basket:

`TT_v(x) = sum_(m,k) p_v[m,k] * x[m,k] / score_v(reference_basket)`.

Exact weights and the reference basket remain explicit product choices. This research does not activate a basis. My recommendation is tariff-reference semantics for a first public basis, with local empirical indices retained as research alternatives.

A tariff-derived TT is mathematically proportional to reference-vintage tariff value. That is not a defect, but it means TT adds **stable units and interpretability**, not new predictive information. Changing current prices need not change that ruler.

Decide whether the reference schedule normalizes away service speed. With a standard-speed reference, identical model/category work has identical TT even if Fast mode consumes more live allowance. The live conversion must then carry the speed distinction. This is coherent; silently changing the meaning between views is not.

A useful basis contract specifies normalization, joint dimensions, unsupported mappings, equivalent-category rules, exact coefficients, source vintage and historical-restatement behavior. A compatible new-model extension can retain existing weights and reference normalization while receiving a new snapshot identity. Compatibility on old coordinates must be explicit; new-model weights must not appear silently.

### Why one TT-to-quota exchange rate is conditional

Absorb normalization into `w`, so `TT = w' x`, and write quota cost as `q = beta' x`. For positive supported TT weights:

`q / TT = sum_k s_k * (beta_k / w_k)`, where `s_k = w_k*x_k/TT` and `sum_k s_k = 1`.

Therefore the conversion is a weighted average of category-specific ratios. A universal exact scalar conversion for arbitrary supported mixtures requires `beta = c*w`. Wolfram verified that condition in a two-category symbolic case.

A scalar conversion may still work over a restricted observed mixture. The product should then say that it applies **at that mixture**, retain the vector route, and expand or withhold the result when the mixture changes beyond validated support.

For fixed known `beta` and an otherwise arbitrary nonnegative supported mixture:

`min_k(beta_k/w_k) <= q/TT <= max_k(beta_k/w_k)`.

Those are deterministic mixture bounds, not calibrated predictive probabilities. Zero-weight dimensions with possible positive quota cost invalidate a finite upper conversion bound and must be handled separately.

## 9. Forecast workload paths, not just independent category totals

### 9.1 Current-work continuation

The first forecast should condition on continuation of a declared recent operating pattern. The pattern includes natural tool waits and burst spacing if those are part of the selected observation interval. It must not assume the user will sleep unless that is part of the chosen scenario.

Begin with the existing recent-rate/elapsed-time baselines. A useful challenger is **joint block resampling** of comparable recent work: resample contiguous workload-vector/time blocks rather than independent category amounts or independently forecasted agents. This can preserve burstiness, cache/output correlation, model pairing and simultaneous activity.

A bootstrap does not invent unseen behavior or prove stationarity. Compatible history, source quality, block selection and held-out performance still determine whether this is useful. Intermittent-demand research provides precedent for forecasting lead-time cumulative demand distributions rather than only point demand; transferring that idea to AI work is a proposal, not an established TajsTokens result. [S8]

### 9.2 Usual future activity

For the separate “will it last until reset?” question, a hurdle decomposition is sensible:

`P(any work during horizon) × E(work amount | some work during horizon)`.

The existing design note already proposes this, so it is not a new missing feature specification. [R6] Start from a simple supported activity pattern and recent positive-work amounts; introduce a small activity classifier and positive-amount model only if they improve future outcomes.

Do not multiply independently fitted mean volume by mean category shares and assume their correlation disappeared. Preserve the joint distribution, or model category amounts conditionally on the volume/activity state.

### 9.3 Counterfactual revaluation is not task prediction

“Replay these same observed tokens under another model's reference weights” is an exact conditional valuation when the mapping is supported.

“Run the same task with another model” changes unknown future token volume, tool use, retries, completion probability and possibly quality. That requires workload/outcome evidence. A model-picker scenario should not imply that holding token volume constant predicts the real changed task. Scenario forecasts are conditional on their supplied predictors; their intervals do not automatically include uncertainty in those assumptions. [S9]

## 10. Runway is a threshold-crossing target

For a future cumulative-consumption path `B(t)` and remaining allowance `R`, define:

`T = inf{t >= 0 : B(t) >= R}`.

There can be substantial probability of **no crossing before reset**. That outcome should not be forced into an arbitrary large finite ETA. A median crossing time may not exist within the relevant horizon.

A path-based model can derive the probability of crossing before the known reset, the crossing-time distribution among paths that cross, and the remaining allowance distribution at a chosen deadline. Each answer must retain the scenario and uncertainty qualification that produced its paths.

For simultaneous short and weekly limits, propagate the **same workload path** through the two window policies. Resets change the respective states at their known times. Do not assume independence between limits driven by the same work, and do not take the minimum of marginal quantiles as though it were the quantile of the first crossing.

The threshold is not automatically a hard interruption time: provider grace, purchased usage and explicitly chosen resets can affect continuation. Treat those as separate policy/scenario inputs. Do not assume an automatic purchase or banked-reset action. [S3]

### Preserve censored outcomes

`QuotaCostObservationBuilder` currently excludes saturated outcomes because the hidden overshoot is not an ordinary bounded delta. That is a defensible boundary for its existing loss. [R2]

A later censoring-aware evaluator could retain them as lower-bound cost evidence, or retain an interval between the last below-threshold and first at-threshold observations. It must not train against the clipped number as the exact latent amount. Censored-data likelihoods are a standard way to retain this kind of information without fabricating an unseen value. [S10]

This matters because excluding all threshold-reaching intervals can remove precisely the high-consumption cases that planning needs. Whether that selection materially affects this dataset remains to be measured.

## 11. Two quota windows may share information, but this is a hypothesis

Separate window targets remain essential. However, independent fitting need not be a permanent restriction.

A testable shared-cost hypothesis is:

`Delta q_short = a_short * g(x)`

`Delta q_weekly = a_weekly * g(x)`.

For fresh aligned intervals wholly inside compatible reset periods, the ratio of latent increments would be constant under that hypothesis. Multiple mixtures are needed to test whether it survives changes in model/category/tier composition. Rounding, lag and shared external work must be handled, and the two readings are not independent replicates of the work.

In matrix terms, a common scalar requires proportional cost vectors. A joint model can therefore test a constrained shared-cost structure against separate per-window vectors. If supported, partial pooling may reduce variance; if contradicted, retain separate conversions. No private provider formula is assumed.

Keep a frozen reference calibration for change detection alongside any adaptive predictor. A provider policy change is only one possible explanation for residual drift. First separate known plan/tier changes, workload composition, source coverage, attribution and reporting behavior.

## 12. Evaluation must distinguish compatibility from predictive coverage

### 12.1 An existing good disclaimer needs to reach the UI

`QuotaAccountingModel` explicitly says its research bands target **80% measurement-envelope intersection**, not calibrated latent coverage or exhaustion probability. [R1] Preserve that qualification. An interval overlapping the set of possible measured outcomes has not necessarily covered the unknown true outcome.

For example, a measurement interval `[9,11]` and prediction interval `[9.9,10.1]` intersect. A compatible true value of `9.2` is nevertheless outside the prediction interval. The included synthetic check verifies this elementary but important distinction.

For trusted measurement sets `A_i` and forecast intervals `P_i`, report two empirical quantities:

- **Certain coverage:** fraction for which `A_i` is wholly contained in `P_i`.
- **Possible coverage:** fraction for which `A_i` intersects `P_i`.

The actual latent coverage is bounded by those two fractions when every true value lies in its declared measurement set. These bounds do not account for a wrong observation contract or unbounded lag. Likewise, point absolute error can be bounded below by distance to the observation interval and above by the farther endpoint when the interval is finite.

### 12.2 Keep probability labels honest

A deterministic feasible range is not a confidence interval. A range of future simulated outcomes is model-conditional until predictive calibration is demonstrated. A coefficient interval is not a prediction interval for a future task. Every range needs its target and assumptions.

Ordinary conformal coverage relies on exchangeability. Research extends it to distribution shift, and adaptive conformal inference can target long-run coverage frequency, but neither provides an automatic reliable guarantee for every particular rare workload or sudden regime change. [S11, S12]

Do not add conformal calibration as a cosmetic wrapper around sparse, biased or incorrectly timed targets. It becomes useful after the target, source coverage and chronological evaluation are sound.

### 12.3 Evaluate the actual operational question

Retain the memo's distinction between reconstructed history and operational replay. Each forecast origin must use only inputs collected by that time; model fitting at the origin must use only outcome labels already available then. Preserve predictions before outcomes mature.

Use chronological rolling-origin evaluation at the requested horizons. Avoid overlap leakage across tuning/evaluation boundaries and block uncertainty summaries by compatible sessions/reset periods where appropriate. The forecasting literature explicitly distinguishes genuine future forecasts from fits that use realized future predictors. [S9, S13]

Compare direct quota and composed forecasts on matched origins, but also show their separate answer availability. Report interval width, signed accumulated error, missed bursts, false exhaustion warnings and warning lead time, not just mean error during mostly idle periods.

The fixed first-20 fit is valuable as a frozen research reference. It is not a universal sample-size theorem or the permanent best production training policy. “Enough rows” should not substitute for workload contrast, support and held-out performance.

## 13. Product contract and bounded implementation sequence

This is a model-semantics recommendation, not a screenshot-based UI audit or a new visual design.

The product snapshot should distinguish:

| Answer | Meaning | Material qualifier |
|---|---|---|
| Measured work | Reconciled tokens and TT under a named basis | Covered sources and dimensions |
| Reported allowance | Provider observation for a specific window | Measurement/collection time and freshness |
| Continue this work | Conditional continuation of a selected operating pattern | Pattern, scope and supported mixture |
| Usual activity outlook | Forecast including expected active and idle time | Historical support and calibration |
| Counterfactual revaluation | Same fixed workload under a different schedule | Not a prediction of changed task behavior |

Useful explanatory states include **exact under basis**, **bounded under stated assumptions**, **partial**, **unsupported mixture**, **stale source**, and **forecast not yet calibrated**. These are not an invented numeric confidence score.

### Recommended order inside the existing owners

**First, evidence and pace correctness.** Complete the memo's ingestion/representation work, repair PACE-001 and retain source-time, account and coverage safeguards. This is still the highest-value prerequisite.

**Second, representation and score semantics.** Add joint model/category projections; give the public TT basis an explicitly versioned representation; support exact equivalent-category aggregation and bounded partial answers. Keep old basis/history semantics intact.

**Third, support-aware calibration.** Add rank/contrast diagnostics and scenario-specific prediction ranges to the existing accounting research. Compare the existing pooled model with a restrained joint model on matched future outcomes. Known external coverage gaps must not be fitted away as local prices.

**Fourth, short-horizon continuation.** Compare the corrected direct baseline, recent joint-workload continuation and a small block-resampling challenger. Keep the feature/fit caches revision-qualified; do not turn each unchanged poll into a fitting job.

**Fifth, threshold outcomes and usual activity.** Add censoring-aware evaluation, coherent short/weekly path propagation and separately validated activity forecasts. Introduce adaptive state estimation or conformal layers only when evidence shows their benefit.

The research helpers can run offline or in the existing bounded calibration process. Wolfram is useful for checking derivations and prototypes; the installed application does not need Wolfram, an LLM call, an always-on Python service or a new database merely to implement these contracts.

## 14. What would change these recommendations?

A complete, fresh provider ledger with authoritative per-response allowance debits could substantially reduce the need to infer cost coefficients. A shared provider unit across both windows could simplify their relationship if its contract were explicit. Conversely, substantial missing cross-surface activity or rapidly changing policies could make a direct account-level forecast more useful than local cost attribution for longer.

A genuinely broad, well-covered dataset might show a simple scalar conversion is adequate over the product's intended workload support. That would justify using it there; it would not prove arbitrary cross-provider universality.

The most important unresolved empirical questions are the actual retained joint-feature coverage, effective sample diversity, reporting lag, external account activity, horizon-specific forecasting performance and the desired TT reference convention. No mathematical demonstration in this package substitutes for those measurements.

## Reproducibility

- `model_checks.py`: independently checks the counterexamples, linear feasibility bounds, endpoint-error covariance, incident arithmetic, elapsed-time decay identity, mixture-conversion bounds and interval-coverage counterexample.
- `check_results.json`: generated output from a successful run.
- `wolfram_checks.wl`: the two evaluated Wolfram expressions, retained for inspection and rerun.

All synthetic weights and observations are explicitly illustrative. The computations establish algebraic properties and failure modes, not fitted production performance.

## Sources

### Repository, pinned at e609aebee78712dd26c2eae040005e6dcf2377f3

[R1] [QuotaAccountingModel.cs](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/src/TajsTokens.Core/Services/Accounting/QuotaAccountingModel.cs). Interval ridge, marginal features, first-20 fit and envelope-intersection evaluation.

[R2] [QuotaCostObservationBuilder.cs](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/src/TajsTokens.Core/Services/Accounting/QuotaCostObservationBuilder.cs). Compatible intervals, measurement assumptions, chronology and saturation exclusion.

[R3] [QuotaPaceModels.cs](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/src/TajsTokens.Core/Services/Forecast/QuotaPaceModels.cs). Existing pace candidates and elapsed-time weighting.

[R4] [CodexForecastFeatureBuilder.cs](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/src/TajsTokens.Core/Services/Forecast/CodexForecastFeatureBuilder.cs). Content-free feature projection and model/effort marginal shares.

[R5] [TtWorkloadBasis.cs](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/src/TajsTokens.Core/Models/TtWorkloadBasis.cs). Five pooled category weights, hashing and support gates.

[R6] [Layered statistical design](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/docs/source-notes/TT_LAYERED_STATISTICAL_DESIGN.md). Existing hurdle, frozen-basis and vector-versus-scalar proposals.

[R7] [Consolidated audit register](https://github.com/tajemniktv/TajsTokens/blob/e609aebee78712dd26c2eae040005e6dcf2377f3/.codex/docs/AUDIT.md). Dated implementation boundaries, not newly rerun runtime results.

### Primary documentation and research

[S1] OECD/European Union/EC-JRC (2008), [Handbook on Constructing Composite Indicators](https://www.oecd.org/en/publications/handbook-on-constructing-composite-indicators-methodology-and-user-guide_9789264043466-en.html), particularly weighting and sensitivity, printed pp. 31–34. Methodological analogy; the handbook does not validate TT.

[S2] OpenAI, [ChatGPT Rate Card: credit-based pricing](https://help.openai.com/en/articles/11481834-chatgpt-rate-card-business-enterpriseedu-credit-based-pricing), consulted 27 October 2026. Scope, speed multipliers, shared usage and pricing notes.

[S3] OpenAI, [Using Codex with your ChatGPT plan](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan), consulted 27 October 2026. Shared allowance, reset and active-turn continuation semantics.

[S4] OpenAI, [Enterprise token-based rate card](https://help.openai.com/en/articles/20001415-chatgpt-rate-card-enterprise-token-based-pricing), consulted 27 October 2026. Billing-route and context/speed distinctions. Not a statement of the user's personal billing contract.

[S5] Stan Development Team, [Problematic Posteriors](https://mc-stan.org/docs/stan-users-guide/problematic-posteriors.html), collinear regression predictors and mitigation. Used for the general identifiability distinction; the numerical examples here are independently derived.

[S6] Stan Development Team, [Measurement Error and Meta-Analysis](https://mc-stan.org/docs/stan-users-guide/measurement-error.html), rounding section. Interval likelihood and latent-measurement formulations.

[S7] Casini, Garulli and Vicino (2017), [A linear programming approach to online set membership parameter estimation for linear regression models](https://doi.org/10.1002/acs.2701), International Journal of Adaptive Control and Signal Processing 31(3), 360–378. Public abstract consulted; the package implements its own elementary illustrative LPs, not the paper's online algorithm.

[S8] Willemain, Smart and Schwarz (2004), [A new approach to forecasting intermittent demand for service parts inventories](https://doi.org/10.1016/S0169-2070(03)00013-X), International Journal of Forecasting 20(3), 375–387. Public abstract consulted; used as methodological precedent, not as evidence that its procedure works for Codex.

[S9] Hyndman and Athanasopoulos, [Forecasting: Principles and Practice, regression forecasting](https://otexts.com/fpp3/regression.html), ex-ante/ex-post and scenario sections.

[S10] Stan Development Team, [Truncated or Censored Data](https://mc-stan.org/docs/stan-users-guide/truncation-censoring.html). Retaining censored observations without fabricating their exact values.

[S11] Barber, Candès, Ramdas and Tibshirani (2023), [Conformal Prediction Beyond Exchangeability](https://www.stat.cmu.edu/~ryantibs/papers/nexcp.pdf). Exchangeability violations, dependence/drift and qualified coverage extensions.

[S12] Gibbs and Candès (2021), [Adaptive Conformal Inference Under Distribution Shift](https://papers.neurips.cc/paper/2021/hash/0d441de75945e5acbc865406fc9a2559-Abstract.html), NeurIPS 34. Long-run coverage frequency is distinct from pointwise conditional guarantees.

[S13] Hyndman and Athanasopoulos, [Forecasting: Principles and Practice, forecaster's toolbox](https://otexts.com/fpp3/toolbox.html), rolling-origin evaluation and predictive assessment.
